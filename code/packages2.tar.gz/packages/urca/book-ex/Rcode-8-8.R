library(vars)
data(Canada)
summary(Canada)
plot(Canada, nc = 2)
