reccusum <- stability(varsimest,
    type = "OLS-CUSUM")
fluctuation <- stability(varsimest,
    type = "fluctuation")
