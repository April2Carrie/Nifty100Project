

// This file support the legacy location and includes from the new location

#include "RcppArmadillo/config/RcppArmadilloConfig.h"
